cmake_minimum_required(VERSION 3.16)
project(ai_workspace_m5 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(Threads REQUIRED)
find_package(Qt6 REQUIRED COMPONENTS Widgets Test)
set(CMAKE_AUTOMOC ON)

# M4 starts from your own M3 project: copy your M3 src/ files here first.
# Add your new M4 source files to the target where they belong.

add_library(aiws_m2
    src/document.cpp
    src/workspace.cpp
    src/text_processor.cpp
    src/chunker.cpp
    src/corpus_index.cpp
    src/retrieval_engine.cpp
    src/context_builder.cpp
    src/processing_core.cpp
)
target_include_directories(aiws_m2 PUBLIC include)
target_link_libraries(aiws_m2 PUBLIC Threads::Threads)
target_compile_options(aiws_m2 PRIVATE -Wall -Wextra -Wpedantic)

# socket helpers and the message format, shared by the app and aiws_send
add_library(aiws_ipc STATIC
    src/remote_protocol.cpp
    include/aiws/ipc/remote_protocol.hpp
)
target_include_directories(aiws_ipc PUBLIC include)
target_compile_options(aiws_ipc PRIVATE -Wall -Wextra -Wpedantic)

# Everything except main(), so tests can link the application code.
add_library(aiws_app STATIC
    src/build_worker.cpp
    src/corpus_state.cpp
    src/remote_add_server.cpp
    src/main_window.cpp
    src/workspace_widget.cpp
    src/search_widget.cpp
    src/context_widget.cpp
    src/term_inspector_widget.cpp
    src/search_result_model.cpp
    include/aiws/build_worker.hpp
    include/aiws/gui/corpus_state.hpp
    include/aiws/ipc/remote_add_server.hpp
    include/aiws/gui/main_window.hpp
    include/aiws/gui/resettable.hpp
    include/aiws/gui/workspace_widget.hpp
    include/aiws/gui/search_widget.hpp
    include/aiws/gui/context_widget.hpp
    include/aiws/gui/term_inspector_widget.hpp
    include/aiws/gui/search_result_model.hpp
)
target_include_directories(aiws_app PUBLIC include)
target_link_libraries(aiws_app PUBLIC aiws_m2 aiws_ipc Qt6::Widgets)
target_compile_options(aiws_app PRIVATE -Wall -Wextra -Wpedantic)

add_executable(ai_workspace_m5 src/main.cpp)
target_link_libraries(ai_workspace_m5 PRIVATE aiws_app)
target_compile_options(ai_workspace_m5 PRIVATE -Wall -Wextra -Wpedantic)

add_executable(aiws_send tools/aiws_send.cpp)
target_link_libraries(aiws_send PRIVATE aiws_ipc)
target_compile_options(aiws_send PRIVATE -Wall -Wextra -Wpedantic)

enable_testing()
add_executable(student_tests tests/student_tests.cpp)
target_link_libraries(student_tests PRIVATE aiws_app Qt6::Test)
target_compile_definitions(student_tests PRIVATE
    AIWS_SEND_PATH="$<TARGET_FILE:aiws_send>"
    AIWS_APP_PATH="$<TARGET_FILE:ai_workspace_m5>")
add_dependencies(student_tests aiws_send ai_workspace_m5)
add_test(NAME student_tests COMMAND student_tests)
set_tests_properties(student_tests PROPERTIES TIMEOUT 60 ENVIRONMENT QT_QPA_PLATFORM=offscreen)
